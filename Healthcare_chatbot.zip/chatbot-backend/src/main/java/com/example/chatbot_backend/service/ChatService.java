package com.example.chatbot_backend.service;

import com.example.chatbot_backend.model.Message;
import com.google.api.core.ApiFuture;
import com.google.cloud.firestore.*;
import com.google.firebase.cloud.FirestoreClient;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;

@Service
public class ChatService {
    public String generateBotReply(String msg) {
        String input = msg.trim().toLowerCase();
        String reply ;

        switch (input) {

                case "hi":
                case "hello":
                    reply = "Hello! 👋 I'm your Cancer Care Assistant. How can I help you today?";
                    break;

                case "i need help":
                case "help":
                    reply = "Sure, I can assist you. Please choose one:\n1. Find nearby treatment centers\n2. Book an appointment\n3. Get emotional support resources";
                    break;

                case "where can i get treatment":
                case "treatment":
                    reply = "Please share your city or ZIP code so I can find cancer care centers near you.";
                    break;

                case "book appointment":
                case "appointment":
                    reply = "Great! Are you a new or returning patient? Please type:\n- New\n- Returning";
                    break;

                case "new":
                    reply = "Please share your full name and preferred date for the appointment. A care coordinator will contact you soon.";
                    break;

                case "returning":
                    reply = "Welcome back! Please enter your patient ID or registered phone number to proceed.";
                    break;

                case "talk to someone":
                case "connect":
                    reply = "You can speak with a care navigator or counselor. Would you like us to connect you now? Type 'Yes' to proceed.";
                    break;

                case "financial help":
                case "aid":
                    reply = "We understand treatment can be costly. We offer information on financial aid and grants. Would you like to explore these options? Type 'Aid'";
                    break;

                case "support groups":
                case "what support groups are available":
                    reply = "We have both online and local support groups for patients and caregivers. Would you prefer:\n1. Online group\n2. Nearby meetings";
                    break;

                case "emergency":
                    reply = "⚠️ If this is a medical emergency, please call 112 immediately. For urgent help related to cancer care, type 'Urgent'.";
                    break;

                case "quit":
                case "exit":
                    reply = "Thank you for reaching out. Stay strong, and remember we're always here to help. 💜 Type 'Hi' if you need anything.";
                    break;

                default:
                    reply = "I'm sorry, I didn't understand that. Please type 'Help' to see what I can assist you with.";
                    break;
            }

            return reply;
    }



        private final Firestore db = FirestoreClient.getFirestore();

        public String registerUser(String userId) throws Exception {
            DocumentReference docRef = db.collection("users").document(userId);
            if (docRef.get().get().exists()) {
                return "User already exists.";
            }
            Map<String, Object> user = new HashMap<>();
            user.put("id", userId);
            docRef.set(user);
            return "User registered successfully.";
        }

    public String sendMessage(String sender, String message) throws Exception {
        String botName = "AdiBot";

        // Store user message
        Map<String, Object> userMsg = new HashMap<>();
        userMsg.put("sender", sender);
        userMsg.put("receiver", botName);
        userMsg.put("message", message);
        userMsg.put("timestamp", FieldValue.serverTimestamp());
        db.collection("chats").add(userMsg);

        // Generate bot reply
        String reply = generateBotReply(message);

        // Store bot reply
        Map<String, Object> botMsg = new HashMap<>();
        botMsg.put("sender", botName);
        botMsg.put("receiver", sender);
        botMsg.put("message", reply);
        botMsg.put("timestamp", FieldValue.serverTimestamp());
        String readableTime = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
        botMsg.put("formattedTime", readableTime);
        db.collection("chats").add(botMsg);

        return "Message sent. AdiBot replied.";
    }

        public List<Message> getMessages(String user1) throws Exception {
            List<Message> messages = new ArrayList<>();
            CollectionReference chats = db.collection("chats");

            Query q1 = chats.whereEqualTo("sender", user1);
            Query q2 = chats.whereEqualTo("reciever", user1);

            List<QueryDocumentSnapshot> docs1 = q1.get().get().getDocuments();
            List<QueryDocumentSnapshot> docs2 = q2.get().get().getDocuments();

            for (QueryDocumentSnapshot doc : docs1) {
                messages.add(doc.toObject(Message.class));
            }
            for (QueryDocumentSnapshot doc : docs2) {
                messages.add(doc.toObject(Message.class));
            }

            messages.sort(Comparator.comparing(Message::getTimestamp));
            return messages;

        }
    }

