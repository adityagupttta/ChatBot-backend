package com.example.chatbot_backend.controller;

import com.example.chatbot_backend.model.Message;
import com.example.chatbot_backend.service.ChatService;
import org.springframework.beans.factory.annotation.Autowire;
import com.google.cloud.firestore.Firestore;
import com.google.firebase.cloud.FirestoreClient;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
@RestController
@RequestMapping("/api")
public class chatbotController{

    @Autowired
    private ChatService chatService;

    @PostMapping("/register")
    public ResponseEntity<String> register(@RequestParam String userId) throws Exception {
        return ResponseEntity.ok(chatService.registerUser(userId));
    }

    @PostMapping("/chat")
    public ResponseEntity<String> chat(@RequestBody Message message) {
        try {
            String userId = message.getSender();         // user sending the message
            String userMsg = message.getMessage();       // the message text

            // 1. Store the user's message in Firebase
            chatService.sendMessage(userId, userMsg);

            // 2. Generate the bot's reply
            String botReply = chatService.generateBotReply(userMsg);

            // 3. Store the bot's reply in Firebase
            chatService.sendMessage(userId,userMsg);  // store as message from bot to user

            // 4. Return reply
            return ResponseEntity.ok(botReply);

        } catch (Exception e) {
            return ResponseEntity.status(500).body("Error: " + e.getMessage());
        }
    }

    @GetMapping("/history/{userId}")
    public ResponseEntity<List<Message>> getChatHistory(@PathVariable String userId) {
        try {
            List<Message> chatHistory = chatService.getMessages(userId);
            return ResponseEntity.ok(chatHistory);
        } catch (Exception e) {
            return ResponseEntity.status(500).build();
        }
    }

}
