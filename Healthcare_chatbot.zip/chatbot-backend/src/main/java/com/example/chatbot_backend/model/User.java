package com.example.chatbot_backend.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

 @Data
@AllArgsConstructor
@NoArgsConstructor// annotation from lomboc library , using this i am skipping the manually writing constructor logic
public class User {
    private String id ;
}
