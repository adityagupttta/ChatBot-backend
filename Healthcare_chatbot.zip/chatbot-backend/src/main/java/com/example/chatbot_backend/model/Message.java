package com.example.chatbot_backend.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import com.google.cloud.Timestamp;

//annotation from lomboc library , using this i am skipping the manually writing constructor logic
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Message {
    private String sender ;
    private String message;
    private Timestamp timestamp;



}
