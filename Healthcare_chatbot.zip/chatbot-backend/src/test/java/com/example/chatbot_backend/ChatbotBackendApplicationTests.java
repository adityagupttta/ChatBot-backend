package com.example.chatbot_backend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ChatbotBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
